@extends('layouts.app')

@section('content')

<!-- ここにページごとのコンテンツを書く -->

@endsection